const display = document.querySelector(".display");
const buttons = document.querySelectorAll("button");

let current = "";
let previous = "";
let operator = "";

/* ===== CALCULATOR ===== */
function updateDisplay(value) {
  display.textContent = value || "0";
}

buttons.forEach(button => {
  button.addEventListener("click", () => {
    const value = button.textContent;

    if (value === "RESET") {
      current = "";
      previous = "";
      operator = "";
      updateDisplay("0");
      return;
    }

    if (value === "DEL") {
      current = current.slice(0, -1);
      updateDisplay(current);
      return;
    }

    if (value === "=") {
      if (!previous || !current) return;

      let a = Number(previous);
      let b = Number(current);
      let result = 0;

      if (operator === "+") result = a + b;
      if (operator === "-") result = a - b;
      if (operator === "x") result = a * b;
      if (operator === "/") result = a / b;

      current = result.toString();
      previous = "";
      operator = "";
      updateDisplay(current);
      return;
    }

    if (["+", "-", "x", "/"].includes(value)) {
      if (!current) return;
      operator = value;
      previous = current;
      current = "";
      return;
    }

    current += value;
    updateDisplay(current);
  });
});


const toggle = document.querySelector(".toggle");
const circle = document.querySelector(".circle");
const body = document.body;
let theme = 1;
toggle.addEventListener("click", () => {
  theme++;
  if (theme > 3) theme = 1;

  if (theme === 1) {
    circle.style.left = "4px";
    body.style.backgroundColor = "rgb(65, 74, 102)";
  }

  if (theme === 2) {
    circle.style.left = "22px";
    body.style.backgroundColor = "rgb(209, 151, 44)";
  }

  if (theme === 3) {
    circle.style.left = "40px";
    body.style.backgroundColor = "rgb(33, 83, 45)";
  }
});
