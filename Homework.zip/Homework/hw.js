/*1*/
const nav = document.getElementById("nav");
const sections = document.querySelectorAll("section");

nav.addEventListener("click", function(event) {
  if (event.target.tagName === "BUTTON") {
    nav.querySelectorAll("button").forEach(btn => btn.classList.remove("active-btn"));
    event.target.classList.add("active-btn");

    const sectionName = event.target.dataset.section;
    sections.forEach(sec => {
      sec.classList.remove("active");
      if (sec.id === sectionName) sec.classList.add("active");
    });
  }
});

/*2*/
const form = document.getElementById("todoForm");
const input = document.getElementById("taskInput");
const list = document.getElementById("list");

form.addEventListener("submit", function(event) {
  event.preventDefault();
  if (input.value.trim() === "") return;

  const li = document.createElement("li");
  li.textContent = input.value;

  const btn = document.createElement("button");
  btn.textContent = "Delete";
  btn.classList.add("delete");

  li.appendChild(btn);
  list.appendChild(li);

  input.value = "";
});

list.addEventListener("click", function(event) {
  if (event.target.classList.contains("delete")) {
    event.target.parentElement.remove();
  }
  if (event.target.tagName === "LI") {
    event.target.classList.toggle("completed");
  }
});

/*3*/
const stars = document.getElementById("stars");
const result = document.getElementById("result");

stars.addEventListener("click", function(event) {
  if (event.target.tagName !== "SPAN") return;

  const rating = event.target.dataset.rate;
  stars.querySelectorAll("span").forEach(star => {
    star.classList.remove("active-star");
    if (star.dataset.rate <= rating) star.classList.add("active-star");
  });

  result.textContent = "Your rating: " + rating;
});

/*4*/
const products = document.getElementById("products");
const cart = document.getElementById("cart");

products.addEventListener("click", function(event) {
  if (event.target.tagName !== "BUTTON") return;
  const name = event.target.dataset.name;

  const li = document.createElement("li");
  li.textContent = name;

  cart.appendChild(li);
});

/*5*/
const langMenu = document.getElementById("langSwitch");
const title = document.getElementById("mainTitle");
const text = document.getElementById("description");

langMenu.addEventListener("click", function(event) {
  if (event.target.tagName !== "BUTTON") return;
  const lang = event.target.dataset.lang;

  if (lang === "en") {
    title.textContent = "Welcome";
    text.textContent = "This is Dias's laptop ";
  }
  if (lang === "ru") {
    title.textContent = "Добро пожаловать";
    text.textContent = "Это ноутбук Диаса";
  }
  if (lang === "kz") {
    title.textContent = "Қош келдіңіз";
    text.textContent = "Бұл Диастың Ноутбугы";
  }
});
