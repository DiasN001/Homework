let count = 5;

function plus() {
  count++;
  document.getElementById("value").textContent = count;
}

function minus() {
  if (count > 0) {
    count--;
    document.getElementById("value").textContent = count;
  }
}

