const heightInput = document.querySelector('.size .field:first-child input');
const weightInput = document.querySelector('.size .field:last-child input');
const banner = document.querySelector('.banner .inform h4');
const bannerText = document.querySelector('.banner .inform p');
function calcBMI() {
    const height = parseFloat(heightInput.value);
    const weight = parseFloat(weightInput.value);
    if (height && weight) {
        const bmi = (weight / ((height / 100) ** 2)).toFixed(1);
        let status = '';
        if (bmi < 18.5) status = 'Underweight';
        else if (bmi < 25) status = 'Normal';
        else if (bmi < 30) status = 'Overweight';
        else status = 'Obese';
        banner.textContent = `Your BMI is ${bmi}`;
        bannerText.textContent = `Status: ${status}`;
    } else {
        banner.textContent = 'Welcome!';
        bannerText.textContent = "Enter your height and weight and you'll see your BMI result here";
    }
}
heightInput.addEventListener('input', calcBMI);
weightInput.addEventListener('input', calcBMI);
