const sw = document.getElementById("switch");
sw.addEventListener("click", () => {
  document.body.classList.toggle("light");
});