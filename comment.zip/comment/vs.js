/*const message = document.getElementById("message");
const btn = document.getElementById("btn");
const StyleBtn= document.getElementById("StyleBtn");
const toggleBtn= document.getElementById("toggleBtn");

btn.addEventListener("click", () =>{
    message.textContent = "Hello! You clicked the button";
});

toggleBtn.addEventListener("click", () => {
    if (message.style.display === "none"){
        message.style.display = "block";
    } else {
        message.style.display = "none";
    }
});



StyleBtn.addEventListener("click", () => {
  message.style.fontSize="32px";
  message.style.border="2px solid red";
  message.style.padding="40px";
  message.style.margin="45px";
  message.style.borderRadius="10px";
});*/

/*const title= document.getElementById("title");
const changeBtn= document.getElementById("changeBtn");

changeBtn.addEventListener("click", () => {
  title.textContent = "САЛАМ-АЛЕЙ-КУММММ!";
});*/



/*const text= document.getElementById("text");
const StyleBtn=document.getElementById("styleBtn");
styleBtn.addEventListener("click", () =>{
    text.style.color="red";
    text.style.fontSize="40px";
});*/


/*const text= document.getElementById("text");
const btn=document.getElementById("btn");
btn.addEventListener("click", () => {
  text.classList.toggle("hidden")
})*/

/*const text=document.getElementById("text");
const sizeBtn=document.getElementById("sizeBtn");
sizeBtn.addEventListener("click", () => {
  text.classList.toggle("big")
});*/

/*const themeBtn=document.getElementById("themeBtn");
themeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
});*/

/*const text = document.getElementById("text");
const btn = document.getElementById("btn");

btn.addEventListener("click" , () => {
    text.classList.toggle("off");
    text.textContent = "STATUS: ON";
});*/



/*const text1 = document.getElementById("text1");
const btn1 = document.getElementById("btn1");

btn1.addEventListener("click", () => {
text1.classList.toggle("selected");
});*/



/*const texts = [
document.getElementById("text1"),
document.getElementById("text2"),
document.getElementById("text3")
];
const toggleBtn = document.getElementById("toggleBtn");
let isCompact = false;
toggleBtn.addEventListener("click", () => {
isCompact = !isCompact;
texts.forEach(text => {
if (isCompact) {
text.classList.add("compact");
} else {
text.classList.remove("compact");
}
});
});*/



/*const badge = document.getElementById("badge");
const toggleBtn = document.getElementById("toggleBtn");
toggleBtn.addEventListener("click", () => {
badge.style.display = badge.style.display === "none" ? "inline-block" : "none";
});/*



/*const likeBtn = document.getElementById("likeBtn");
likeBtn.addEventListener("click", () => {
likeBtn.classList.toggle("liked");
likeBtn.textContent = likeBtn.classList.contains("liked") ? "Liked" : "Like";
});*/



/*const longText = document.getElementById("longText");
const toggleBtn = document.getElementById("toggleBtn");
toggleBtn.addEventListener("click", () => {
const isHidden = longText.classList.toggle("hidden");
toggleBtn.textContent = isHidden ? "Read More" : "Read Less";
});*/



/*const lockBtn = document.getElementById("lockBtn");
lockBtn.addEventListener("click", () => {
lockBtn.classList.toggle("unlocked");
lockBtn.textContent = lockBtn.classList.contains("unlocked") ? "Unlocked" : "Locked";
});*/



/*const cards = document.querySelectorAll(".card");
const toggleBtn = document.getElementById("toggleBtn");
let hidden = false;
toggleBtn.addEventListener("click", () => {
hidden = !hidden;
cards.forEach(card => card.classList.toggle("hidden", hidden));
});*/


/*const loadBtn = document.getElementById("loadBtn");
loadBtn.addEventListener("click", () => {
loadBtn.classList.toggle("loading");
loadBtn.textContent = loadBtn.classList.contains("loading") ? "Loading..." : "Ready";
});*/
