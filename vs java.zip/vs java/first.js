/*let name = "Dias";
let surname = "Niyazaly";
console.log(name,surname);

/*let x = 80;
let y = 100;
console.log(x, y);
console.log(x + y);

/*let num1 = 200
let num2 = 300
let num3 = 500
console.log(num1,num2,num3)
console.log(num1 - num2 + num3)
console.log(num1 + num2 + num3)
console.log(num3 - num1)

/*let age = 22;
console.log(age);
let текст = "Прошел Год"
console.log(age + 1);

/*let numb1 = Number(prompt());
let numb2 = Number(prompt());
console.log(numb1 + numb2);

/*let numbe1 = Number(prompt());
console.log(numbe1+5);

/*let number1 = Number(prompt());
let number2 = Number(prompt());
console.log(number1 ** number2);

/*let n = Number(prompt());
console.log(n % 4);

/*let n = Number(prompt());
console.log(n % 10);

let a = Number(prompt());
let b = Number(prompt());
let c = Number(prompt());
console.log((b**2 - 4*a*c)**1/2);

let x = Number(prompt());
let y = Number(prompt());
console.log(x > y)

let x = Number(prompt());
if(x>0){
    console.log("Положительное");}

let s = Number(prompt())
if(s>100 && s<1000){
    console.log("Трехзначное")
};*/

/*let x = Number(prompt());
if (x>=1000);{
    console.log(x-x*10/100);
    console.log("Спасибо за покупку")
}
if (x<1000);{
    console.log("Спасибо за покупку")
}*/

/*let n = Number(prompt())
if ( n > 0) {
    console.log("Положительное")
} else if ( n === 0 ) {
    console.log("Не положительное и не отрицательное")
} else {
    console.log("Отрицательное")
}*/

/*let n = Number(prompt())
if ( n === 84) {
    console.log("Отлично")
} else if ( n === 64) {
    console.log("Хорошо")
} else if ( n === 0) {
    console.log("Учись")
} */

/*let n = Number(prompt())
if ( n > 0 && n < 11) {
    console.log("Доброе утро")
} else if (n > 12 && n < 17 ) {
    console.log("Добрый день")
} else if (n > 18 && n < 23 ) {
    console.log("Добрый вечер")
}*/



/*let grade = 45 
let admisson = (grade >=50)? "Допущен": "Не допущен";
console.log("Допуск на экзамен:" + admisson );*/


/*let age = Number(prompt())
let nitro = (age >=18)? "Доступ разрешен":"Доступ запрещен";
console.log(nitro);*/

/*let a = Number(prompt());
let b = (a >=5)? "200рублей" : "350рублей";
console.log("Стоимость доставки:  " + b );*/

/*let weight = Number(prompt());
let status = prompt();
let price;
if (weight <= 5) {
  if (status === "экспресс") {
    price = "1000 руб";
  } else if (status === "обычная") {
    price = "500 руб";
  } else {
    price = "Некорректный статус доставки";
  }
} else {
  if (status === "экспресс") {
    price = "1500 руб";
  } else if (status === "обычная") {
    price = "800 руб";
  } else {
    price = "Некорректный статус доставки";
  }
}
console.log("Стоимость доставки: " + price);*/

/*let count = Number(prompt("Enter a starting number:"));
let limit = Number(prompt("Enter an ending number:"));
while (count <= limit){
    console.log("Count is: " + count);
    count = count + 1;
}*/

/*let a = Number(prompt());
let b = 1;
let limit = 10 * a;
while (b < limit){
    console.log(a*b);
    n2++;
}*/

/*let a = Number(prompt());
console.log(2**a);*/



/*homework*/

/* let a=Number(prompt());
let b=Number(prompt());
let count=0;
for(let i=b; i>=a; i--){
console.log(i)
}*/


/*let a=Number(prompt());
count=0;
for (let i = 1; i <= a; i += 2) {
count += i;
}
console.log(count);*/


/*let a=Number(prompt());
let b = 0;
let c = 0;
for (let i = 1; i <= a; i++) {
    if (i % 2 === 0) {
       b++;
} else {
       c++;
   }
console.log("Четных чисел:" + b);
console.log("Нечетных чисел:" + c);*/


/*let a = Number(prompt());
let i=0;
while(a<=1000){
    a*=2;
    i++;
}
console.log("Итоговое число:" + a);
console.log("Количество итераций:" * i)*/


/*15.01.2026*/

/*function calculateSum(){
    let sum = 0;
    for (let i = 1; i <= 5; i++){
        sum += i;
    }
    console.log(sum);
}*/

/*function calculateSum(){
    let a = (prompt());
    let b = a ** 2 ;
    console.log(b);
}
calculateSum();*/


/*function getUserInfo(){
    let name = (prompt());
    let age = (prompt());

    console.log=("Привет," + name + "Тебе " + age + "лет");
}

getUserInfo();*/

/*function calculateSum() {
    let a = Number(prompt("Enter first number:"));
    let b = Number(prompt("Enter second number:"));

    if (a > b) {
        console.log(a + " больше чем " + b);
    } else if (a < b) {
        console.log(b + " больше чем " + a);
    } else {
        console.log(a + " равен " + b);
    }
}

calculateSum();*/


/*function calculateSum(){
    let a = Number(prompt("Enter first number:"));
    let b = Number(prompt("Enter second number:"));
    let c = Number(prompt("Enter third number:"));
    let d = Number(prompt("Enter fourth number:"));

    if (a >= b && a >= c && a >= d) {
    console.log(a);
} else if (b >= a && b >= c && b >= d) {
    console.log(b);
} else if (c >= a && c >= b && c >= d) {
    console.log(c);
} else {
    console.log(d);
}

}

calculateSum();*/

/*function calculateSum(){
    let a = Number(prompt("Enter first number:"));
    let b = Number(prompt("Enter second number:"));
    let c = (prompt());
    function sum(a,b) {
        return a+b;
    }
    function minus(a,b) {
        return a-b;
    }
    function mult(a,b) {
        return a * b;
    }
    function division(a,b) {
        return a / b;
    }
    if ( c === "+"){
        console.log(sum(a,b));
    }
    else if ( c === "-"){
        console.log(minus(a,b));
    }
    else if ( c === "*"){
        console.log(mult(a,b));
    }
    else if ( c === "/"){
        console.log(division(a,b));
    }
    else{
        console.log("INVALID operation")
    }
}
calculateSum();*/


/*let brand = (prompt("Car brand:"));
let model =(prompt("Car model:"));
let car = {
    brand,
    model,
};
console.log(car.brand);
console.log(car.model);*/

/*let subj = prompt("Subject:");
let mark = prompt("Mark:");
let student = {
    subject: subj,
    mark: mark,
};
console.log("Специальность студента: " + student.subject);
console.log("Средний балл студента: " + student.mark);*/

/*let city = prompt("Место назначения:");
let date = prompt("Дата начала путешествия:");
let day = prompt("Длительность путешествия (в днях):");

let trip = {
    city: city,
    date: date,
    day: day,
};

console.log(trip.city);
console.log(trip.date);
console.log(trip.day);
console.log(trip.date + " вы отправляетесь в " + trip.city + " на " + trip.day + " дней");*/

/*let book = prompt("Название книги:");
let author = prompt("Автор книги:");
let date = prompt("Год издания книги:");

let info = {
    book: book,
    author: author,
    date: date,
};

console.log("Название книги:" + info.book);
console.log("Автор книги:" + info.author);
console.log("Год издания книги:" + info.date);*/

/*const person = {
    name:"Василий",
    age: 97,
    sayHello () {
        console.log("Hello");
    }
};*/

/*let a = +prompt();
let b = +prompt();
const x = {
    a,
    b,
    divide(){
        return a % b
    }
}
console.log(x.divide)*/

/* Task33
let gg = {
    number1: Number(prompt()),
    number2: Number(prompt()),
}
console.log(gg.number1 % gg.number2);
*/

/*let money = Number(prompt());

let bank = {
    showBalance: function(balance) {
        console.log("Ваш текущий баланс: " + balance + " долларов");
    }
};
bank.showBalance(money);*/

/*
let myObject = {
    base: 2,
    a: function (y) {
        return Math.pow(y - this.base, y);
    }
};
let y = Number(prompt("Введите число Y:"));
let result = myObject.a(y);
console.log("Результат:", result);


let bankAccount = {
    balance: 500,

    deposit: function (amount) {
        this.balance = this.balance + amount;
        return this.balance;
    },

    withdraw: function (amount) {
        if (amount > this.balance) {
            return "Недостаточно средств на счете";
        } else {
            this.balance = this.balance - amount;
            return this.balance;
        }
    }
};

let amount = Number(prompt("Введите сумму"));
let choice = prompt("Введите операцию: внести или снять");

if (choice === "внести") {
    alert(bankAccount.deposit(amount));
} else if (choice === "снять") {
    alert(bankAccount.withdraw(amount));
}*/

/*console.log("Да?\nАлё!\nда да?\nНу как там с \"деньгами\"?\nА?\nКак с \"деньгами\"-то там?\nЧё с \"деньгами\"?\nЧё");*/

/*const name = prompt();
const age = prompt();
const result = `Имя: ${name}, Возраст: ${age} лет`
console.log(result);*/

/*CalculateProfite*/

/*let money = Number(prompt("Доход:"));
let nomoney = Number(prompt("Расход:"));
const profit = {
    money,
    nomoney,
    divide() {
        return this.money - this.nomoney;
    }
};

const result = `Ваша прибыль составляет ${profit.divide()} рублей`;
console.log(result);*/

/*let product = (prompt());
let price = (prompt());
let quantity = (prompt());
function calculateTotal(price, quantity) {
    return price * quantity;
}

let total = calculateTotal(price, quantity);

console.log(
    "Вы выбрали " + quantity + " товаров " + product + " по цене " + price + " рублей за штуку. Итого: " + total + " рублей");*/

/*function calculateTotal() {
    let product = prompt("Название товара:");
    let price = Number(prompt("Цена за штуку:"));
    let quantity = Number(prompt("Количество:"));

    console.log(
        "Вы выбрали " + product +
        " по цене " + price + " рублей за штуку.\n" +
        "Количество: " + quantity + " шт\n" +
        "Итого: " + (price * quantity) + " рублей"
    );
}

calculateTotal();*/

/*let a = prompt();

if ( a.length > 5){
    console.log (`${a}!`)
} else if (a.length < 5){
    console.log (`${a}?`)
}*/

/*let text = prompt("Введите строку:");
for (let i = 0; i < text.length; i++) {
    console.log(text[i].toLowerCase());
}*/

/*let text = prompt("Введите строку:");

if (text.length < 2) {
    console.log("Строка слишком короткая");
} else {
    console.log(text[text.length - 2] + text[text.length - 1]);
} */ 

/*const randomNum = Math.random(); */

/*const randomNum = Math.round(Math.random() * 10);
let minNumber = Math.min(5, 3, 9, 1, 7);
let maxNumber = Math.max(5, 3, 9, 1, 7);

console.log(minNumber); 
console.log(maxNumber); */

/*let users = [];
let name1 = prompt("Введите первое имя:");
let name2 = prompt("Введите второе имя:");
users.push(name1);
users.push(name2);
console.log(users);*/

/*let users = [];
let name1 = prompt();
let name2 = prompt();
let name3 = prompt();
users.push(name1, name2, name3);
console.log(users[0] , users[2]);*/

/*let arr = [];
let n = Number(prompt("Введите количество элементов массива:"));
for (let i = 0; i < n; i++) {
    let element = prompt("Введите элемент массива:");
    arr.unshift(element);
}
console.log(arr);*/

/*let text = prompt("Введите текст:"); 
let words = text.split(" "); 
let output = [];
let max = 4; 

for (let i = 0; i < words.length; i++) {
    let num = i + 1;
    if (num > max) num = max;
    output.push(num);
}

console.log(output.join("[,]"));*/

/*function calculateTotal(name, price, count) {
    let total = price * count;
    return Вы выбрали ${count} товаров "${name}" по цене ${price} рублей за штуку. Итого: ${total} рублей.;
}*/

/*function calculateTotal(name, price, count) {
    console.log(`Вы выбрали "${name}" по цене ${price} рублей за штуку.\nКоличество: ${count} шт.\nИтого: ${price * count} рублей.`);
}*/

/*let s = prompt();
if (s.includes('д') || s.includes('н')) {
    console.log(s.toUpperCase());
} else {
    console.log(s.toLowerCase());
}*/

/*let s = prompt();

if (s.startsWith('ж') || s.startsWith('Ж')) {
    console.log(s.length);
} else {
    console.log("Попробуйте снова");
}*/

/*let text = prompt();
let ch = prompt();
text = text.toLowerCase();
ch = ch.toLowerCase();
let count = 0;
for (let c of text) {
    if (c === ch) {
        count++;
    }
}
console.log(`Символ "${ch}" встречается ${count} раз(-а)`);*/

/*let s = prompt();
let result = s
    .toLowerCase() 
    .split('') 
    .reverse()
    .join('');

console.log(result);*/

/*let n = Number(prompt());
if (n < 0) {
    n = Math.abs(n);
}
let sqrt = Math.sqrt(n);
console.log(`Квадратный корень из ${n} равен ${sqrt}`);*/

/*let r = Number(prompt());
let S = Math.PI * r * r;
let result = Math.pow(S, 3);
console.log(Math.round(result));*/

/*const days = [
  "Понедельник","Вторник","Среда",
  "Четверг","Пятница","Суббота","Воскресенье"
];

const people = [
  { id: 1, name: "Иван", age: 30 },
  { id: 2, name: "Мария", age: 25 },
  { id: 3, name: "Алексей", age: 35 },
  { id: 4, name: "Елена", age: 28 }
];

const months = [
  "Январь","Февраль","Март","Апрель",
  "Май","Июнь","Июль","Август",
  "Сентябрь","Октябрь","Ноябрь","Декабрь"
];

const output = days.concat(people, months);

console.log(output);*/

/*let input = prompt();
let result = input.split(', ');
console.log(result);*/

/*let a = prompt("Введите данные через запятую и пробел");

let array = a
    .split(", ")
    .map(item => Number(item));

console.log(array.join(", "));*/

/*let a = prompt("Введите данные через запятую и пробел");

let array = a.split(", ").map(item => {
    let num = Number(item);
    if (!isNaN(num)) {
        return num;
    } else {
        return `"${item}"`;
    }
});

console.log(array.join(", "));*/

/*Homework*/
/*let array = prompt().split(", ");
let indexes = prompt().split(", ");
for (let i = 0; i < indexes.length; i++) {
  console.log(array[indexes[i]]);
}*/

/*let text = prompt().split(", ");
let indexes = prompt().split(", ");
let result=[];
for (let i of indexes) {
  result.push(text[i]);
}
console.log(result.join(' '))*/

/*let array = [];
let a = prompt();
let b = prompt();
let c = prompt();

function  addToArr(){
    array.push(a , b , c);
    console.log(array);
}
addToArr();*/

/*let text = prompt("");
console.log(text.toUpperCase());*/

/*let arr = [];
for (let i = 0; i < 5; i++) {
  let value = prompt("");
  arr.push(value);
}
console.log(arr[arr.length - 1]);*/

/*let arr = [];
let even = [];

for (let i = 0; i < 4; i++) {
  arr.push(Number(prompt()));
}
for (let i = 0; i < arr.length; i++) {
  if (arr[i] % 2 === 0) {
    even.push(arr[i]);
  }
}
console.log(even);*/

/*let arr = [];
for (let i = 0; i < 3; i++) {
  let str = prompt("");
  arr.push(str);
}
arr.reverse();
console.log(arr);*/

/*let str = prompt();
console.log(str[0].toLowerCase());*/

/*let sum = 0;

for (let i = 0; i < 3; i++) {
  sum += Number(prompt());
}

console.log(sum);*/

/*let n = Number(prompt());

if (n % 5 === 0) {
  console.log("yes");
} else {
  console.log("no");
}*/

/*let x = Number(prompt());

console.log(x * 1);
console.log(x * 2);
console.log(x * 3);
console.log(x * 4);
console.log(x * 5);
console.log(x * 6);
console.log(x * 7);
console.log(x * 8);
console.log(x * 9);
console.log(x * 10);*/

/*let count = 0;

let a = Number(prompt());
let b = Number(prompt());
let c = Number(prompt());
let d = Number(prompt());
let e = Number(prompt());
let f = Number(prompt());

if (a > 0) count++;
if (b > 0) count++;
if (c > 0) count++;
if (d > 0) count++;
if (e > 0) count++;
if (f > 0) count++;

console.log(count);*/

/*let password = prompt();

if (password.length >= 6) {
  console.log("strong");
} else {
  console.log("weak");
}*/

/*let a = prompt();
let b = "";

for (let i = 0; i < a.length; i +=2){
    b += a [i];
}
console.log(b);*/

/*let n = prompt("Введите число от 1 до 7");

if (n == 1) {
    console.log("Monday");
}
else if (n == 2){
    console.log("Tuesday");
}
else if (n == 3) {
    console.log("Wednesday");
}
else if (n == 4) {
    console.log("Thursday");
}
else if (n == 5) {
    console.log("Friday");
}
else if (n == 6) {
    console.log("Saturday");
}
else if (n == 7) {
    console.log("Sunday");
}
else console.log("Ошибка");*/

/*function countVowels(str) {
    let a = 0;
    let b = "aeiou";
    for (let c of str.toLowerCase()) {
        if (b.includes(c)) {
            a++;
        }
    }
    return a;
}
console.log(countVowels("banana")); */

/*const dates = ["25.10.1917","22.06.1941","09.05.1945","26.12.1991"];
const years = dates.map(function(date){
    const parts = date.split(".");
    return parts[2];
})
console.log(years.join(","));*/


/*const capitals = ["Токио", "Афины", "Нью-Дели", "Сеул", "Джакарта", "Багдад", "Астана", "Москва", "Анкара"];
const filteredCapitals = capitals.filter(city => city.startsWith("А"));
console.log(filteredCapitals.join(" "));*/


/*let input = prompt();
let capitals = input.split(" ");
let result = [];
if (capitals.includes("Андорра-Ла-Велла")) {
  for (let city of capitals) {
    if (city.endsWith("а")) {
      result.push(city);
    }
  }
} else {
  for (let city of capitals) {
    if (city.endsWith("н")) {
      result.push(city);
    }
  }
}
console.log(result);*/


/*const input = prompt("Введите слова через пробел:");
const wordsArray = input.split(" ");
const upperCaseWords = wordsArray.map(word => word.toUpperCase());
console.log(upperCaseWords);*/


/*const input2 = prompt("Введите имена через запятую с пробелом:");
const namesArray = input2.split(", ");
const farewellArray = namesArray.map(name => "Пока, " + name);
console.log(farewellArray);*/


/*const cities = ["Москва", "Санкт-Петербург", "Саратов", "Магадан", "Ярославль", "Самара", "Якутск"];
let city = prompt();

if (!cities.includes(city)) {
  console.log("Такого города нет в списке");
} else {
  let letter = city[0];
  let result = cities.filter(c => c[0] === letter);
  console.log(`Города, начинающиеся с буквы "${letter}": ${result.join(", ")}`);
}*/

/*const prices = [1000, 2500, 5000];
const formattedPrices = prices.map(price => `Цена: ${price} тг`);
console.log(formattedPrices); */

/*const numbers = [-5, 10, 0, 8, -2];
const positiveNumbers = numbers.filter(num => num > 0);
console.log(positiveNumbers);*/

/*const students = ["Алия", "Диас", "Айша", "Нуржан"];
const allowed = ["Айша", "Диас"];
const admittedStudents = students.filter(student => allowed.includes(student));
console.log(admittedStudents);*/

/*const words = ["яблоко", "банан", "груша"];
const numberedWords = words.map((word, index) => `${index + 1}. ${word}`);
console.log(numberedWords);*/

/*const numbers = [10, 20, 30, 40];
const average = numbers.reduce((sum, num) => sum + num, 0) / numbers.length;
const aboveAverage = numbers.filter(num => num > average);
console.log(aboveAverage); */

/*const numbers = [1, 2, 3, 4, 5];
const result = numbers.map(num => (num % 2 === 0 ? "even" : "odd"));
console.log(result);*/

/*const prices = [1000, 2000, 3000];
const pricesWithVat = prices.map(price => price * 1.12);
console.log(pricesWithVat);*/

/*const words = ["мир","программа","код","алгоритм"];
const filteredWords = words.filter(word => !word.includes("а"));
console.log(filteredWords);*/
 

/*Homeworks*/

/*const grades = [45, 60, 75, 30];
const statuses = grades.map(grade => grade >= 60 ? "pass" : "fail");
console.log(statuses);*/


/*const products = [
  { name: "Laptop", price: 120000 },
  { name: "Mouse", price: 3000 },
  { name: "Phone", price: 90000 }
];

const expensiveProductNames = products
  .filter(product => product.price > 5000)
  .map(product => product.name);
console.log(expensiveProductNames);*/


/*const words = ["апельсин", "банан", "яблоко", "груша"];
const vowels = "аеёиоуыэюя";
const startsWithVowel = words.filter(word => 
  vowels.includes(word[0].toLowerCase())
);

console.log(startsWithVowel); */


/*const input = "2, 5, 10"; 
const numbers = input.split(",").map(Number);
const squares = numbers.map(num => num ** 2);
console.log(squares);*/


/*const userWords = ["дом", "программа", "код", "ноутбук"];
const longWords = userWords.filter(word => word.length > 5);
console.log(longWords);*/


/*const numbersArray = [10, -5, 0, 3, -1];
const signs = numbersArray.map(num => {
  if (num > 0) return "+";
  if (num === 0) return "0";
  return "-";
});
console.log(signs);*/


/*const wordsToReverse = ["код", "мир", "js"];
const reversed = wordsToReverse.map(word => 
  word.split("").reverse().join("")
);
console.log(reversed);*/