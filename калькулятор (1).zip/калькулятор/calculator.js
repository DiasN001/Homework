const display = document.querySelector(".display");
const buttons = document.querySelectorAll("button");

let current = "";
let prev = "";
let operator = "";

buttons.forEach(btn => {
  btn.addEventListener("click", () => {
    const val = btn.textContent;
    if (val === "C") {
      current = "";
      prev = "";
      operator = "";
      display.textContent = "0";
      return;
    }
    if (val === "←") {
      current = current.slice(0, -1);
      display.textContent = current || "0";
      return;
    }
    if (val === "=") {
      if (!prev || !current) return;

      let a = Number(prev);
      let b = Number(current);
      let res = 0;

      if (operator === "+") res = a + b;
      if (operator === "−") res = a - b;
      if (operator === "×") res = a * b;
      if (operator === "÷") res = b === 0 ? "Error" : a / b;

      display.textContent = res;
      current = res.toString();
      prev = "";
      operator = "";
      return;
    }
    if (btn.classList.contains("op")) {
      if (!current) return;
      operator = val;
      prev = current;
      current = "";
      return;
    }

    current += val;
    display.textContent = current;
  });
});
