let quantity = 0;
document.getElementById("plus").onclick = () => {
  quantity++;
  document.getElementById("quantity").textContent = quantity;
};

document.getElementById("minus").onclick = () => {
  if (quantity > 0) quantity--;
  document.getElementById("quantity").textContent = quantity;
};
