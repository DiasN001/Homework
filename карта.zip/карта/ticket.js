const avatarInput = document.getElementById("avatar");
const preview = document.getElementById("preview");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const githubInput = document.getElementById("github");
const register = document.getElementById("register");
const ticket = document.getElementById("ticket");
const tName = document.getElementById("Name");
const tFullName = document.getElementById("ticketFullName");
const tGithub = document.getElementById("ticketGithub");
const tId = document.getElementById("ticketId");
const ticketAvatar = document.getElementById("ticketphoto");
const body = document.body;

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function generateTicketId() {
    return Math.floor(100000 + Math.random() * 900000); 
}

function formatGithub(username) {
    return username.startsWith("@") ? username : "@" + username;
}

avatarInput.addEventListener("change", function () {
    const file = avatarInput.files[0];
    if (!file) return;

    if (file.size > 500 * 1024) {
        alert("Файл 500kb-тан үлкен болмауы керек!");
        avatarInput.value = "";
        preview.style.display = "none";
        return;
    }
    preview.src = URL.createObjectURL(file);
    preview.style.display = "block";
});
function next() {
    if (
        nameInput.value === "" ||
        emailInput.value === "" ||
        githubInput.value === ""
    ) {
        alert("Барлық қатарды толтырыңыз!");
        return;
    }
    if (!isValidEmail(emailInput.value)) {
        alert("Дұрыс email енгізіңіз!");
        return;
    }
    register.classList.remove("active");
    ticket.classList.add("active");
    tName.textContent = nameInput.value;
    tFullName.textContent = nameInput.value;
    tGithub.textContent = formatGithub(githubInput.value);
    ticketAvatar.src = preview.src;
    tId.textContent = generateTicketId();
}
const themeBtn = document.getElementById("themeBtn");
themeBtn.addEventListener("click", function() {
    document.body.classList.toggle("light-mode");
});
