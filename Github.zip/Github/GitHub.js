const themeBtn = document.getElementById("themeBtn");
const themeText = document.getElementById("themeText");
const themeImg  = document.getElementById("themeImg");
let isLight = false;
function applyTheme(){
  document.body.classList.toggle("light", isLight);
  if(isLight){
    themeText.textContent = "DARK";
  } else {
    themeText.textContent = "LIGHT";
  }
}
themeBtn.addEventListener("click", ()=>{
  isLight = !isLight;
  applyTheme();
});

applyTheme();