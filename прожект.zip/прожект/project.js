const btn = document.getElementById("themeBtn");

btn.onclick = () => {
  document.body.classList.toggle("light");

  if (document.body.classList.contains("light")) {
    btn.textContent = "☀️";
  } else {
    btn.textContent = "🌙";
  }
};
