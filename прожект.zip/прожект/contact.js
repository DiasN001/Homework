const btn = document.getElementById("themeBtn");

btn.onclick = () => {
    document.body.classList.toggle("light");

    btn.textContent =
        document.body.classList.contains("light")
        ? "☀️"
        : "🌙";
};
const form = document.querySelector("form");
const email = document.getElementById("email");
const error = document.getElementById("error");

form.onsubmit = function(e) {
    const value = email.value.trim();

    if (!value.endsWith("@gmail.com")) {
        e.preventDefault();
        error.textContent = "Only Gmail allowed!";
        email.style.border = "2px solid red";
    } else {
        error.textContent = "";
        email.style.border = "2px solid green";
    }
};
