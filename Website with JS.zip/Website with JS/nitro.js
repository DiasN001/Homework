const textInput = document.getElementById("textInput");
const charCount = document.getElementById("charCount");
const wordCount = document.getElementById("wordCount");
const sentenceCount = document.getElementById("sentenceCount");
const themeBtn = document.getElementById("themeBtn");


textInput.addEventListener("input", () => {
  charCount.textContent = textInput.value.length;
  let words = textInput.value.split(" ");
  wordCount.textContent = words.length;
  let sentences = textInput.value.split(".");
  sentenceCount.textContent = sentences.length;
});

themeBtn.addEventListener("click", () => {
  document.body.style.background = "orange";
});

