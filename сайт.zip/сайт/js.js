const btn = document.getElementById("themeToggle");
btn.addEventListener("click", () => {
    if(document.body.style.backgroundColor === "rgb(255, 255, 255)") {
        document.body.style.backgroundColor = "rgb(25, 25, 44)"; 
        document.body.style.color = "white";
        btn.textContent = "Dark";
    } else {
        document.body.style.backgroundColor = "rgb(91, 91, 91)"; 
        document.body.style.color = "black";
        btn.textContent = "Light";
    }
});